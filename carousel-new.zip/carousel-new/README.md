# Carousel-new

A Pen created on CodePen.

Original URL: [https://codepen.io/Mahajan-Kapil/pen/MWNVqKV](https://codepen.io/Mahajan-Kapil/pen/MWNVqKV).

